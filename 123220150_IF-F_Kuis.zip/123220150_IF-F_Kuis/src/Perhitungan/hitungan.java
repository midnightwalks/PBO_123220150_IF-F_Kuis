package Perhitungan;

public interface hitungan {
    public double JumlahAnak();
    public double JumlahRemaja();
    public double JumlahDewasa();
}
