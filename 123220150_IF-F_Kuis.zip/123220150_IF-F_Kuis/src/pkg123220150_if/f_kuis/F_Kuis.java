package pkg123220150_if.f_kuis;

public class F_Kuis {

    public static void main(String[] args) {
        new login();
    }
    
}
